import os, sys, unittest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
for k in ("GROQ_API_KEY", "GEMINI_API_KEY", "OPENAI_API_KEY"):
    os.environ.pop(k, None)
import app as appmod


class Backend(unittest.TestCase):
    def setUp(self):
        appmod._hits.clear()
        self.c = appmod.app.test_client()

    def ask(self, q):
        return self.c.post("/api/ask", json={"query": q}).get_json()

    def test_health_and_catalog(self):
        self.assertTrue(self.c.get("/api/health").get_json()["ok"])
        self.assertEqual(len(self.c.get("/api/catalog").get_json()["domains"]), 8)

    def test_probes(self):
        cases = {
            "Whom should I contact for academic problems?": "academics",
            "Where can I find the examination timetable?": "examinations",
            "Whom should I contact for placement training?": "placements",
            "How can I raise a hostel complaint?": "hostel",
        }
        for q, src in cases.items():
            r = self.ask(q)
            self.assertEqual(r["status"], "grounded", q)
            self.assertEqual(r["sources"][0]["id"], src, q)

    def test_unknown_not_invented(self):
        r = self.ask("What is the exact date of my next examination?")
        self.assertEqual(r["status"], "unavailable")
        self.assertIn("not in the supplied campus data", r["answer"])

    def test_no_substring_false_match(self):
        self.assertEqual(self.ask("does this match anything")["sources"], [])

    def test_validation(self):
        self.assertEqual(self.c.post("/api/ask", json={}).status_code, 400)
        self.assertEqual(self.c.post("/api/ask", json={"query": "a" * 501}).status_code, 400)
        self.assertEqual(self.c.get("/nope").status_code, 404)

    def test_rate_limit(self):
        appmod.RATE_LIMIT = 3
        codes = [self.c.post("/api/ask", json={"query": "hostel"}).status_code for _ in range(5)]
        appmod.RATE_LIMIT = 30
        self.assertEqual(codes[-1], 429)


if __name__ == "__main__":
    unittest.main()
