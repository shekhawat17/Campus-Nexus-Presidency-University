const log = document.getElementById("log");
const form = document.getElementById("form");
const input = document.getElementById("q");

function add(text, cls, meta) {
  log.querySelector(".empty")?.remove();
  const d = document.createElement("div");
  d.className = "msg " + cls;
  d.textContent = text;
  if (meta) {
    const m = document.createElement("span");
    m.className = "meta";
    m.append(meta);
    d.append(m);
  }
  log.append(d);
  log.scrollTop = log.scrollHeight;
  return d;
}

async function ask(query) {
  add(query, "user");
  const wait = add("Checking campus data…", "bot");
  const body = { query };
  const g = document.getElementById("groqKey").value.trim();
  const m = document.getElementById("geminiKey").value.trim();
  if (g) body.groqKey = g;
  if (m) body.geminiKey = m;
  try {
    const r = await fetch("/api/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const data = await r.json();
    wait.remove();
    if (!data.ok) return add(data.error || "Something went wrong.", "bot unavailable");
    const bot = add(data.answer, "bot " + (data.status === "unavailable" ? "unavailable" : ""));
    const meta = document.createElement("span");
    meta.className = "meta";
    const tag = document.createElement("span");
    tag.className = "tag";
    tag.textContent = data.status === "unavailable" ? "Not in campus data" : "Grounded";
    meta.append(tag, (data.sources || []).map(s => s.label).join(", ") || "No source matched", " · " + data.model);
    bot.append(meta);
  } catch {
    wait.remove();
    add("Could not reach the server. Check that app.py is running.", "bot unavailable");
  }
}

form.addEventListener("submit", e => {
  e.preventDefault();
  const q = input.value.trim();
  if (!q) return;
  input.value = "";
  ask(q);
});

fetch("/api/catalog").then(r => r.json()).then(({ domains }) => {
  const ul = document.getElementById("topics");
  domains.forEach(d => {
    const li = document.createElement("li");
    const b = document.createElement("button");
    b.type = "button";
    b.textContent = d.label;
    b.title = d.summary;
    b.onclick = () => ask("Tell me about " + d.label.toLowerCase());
    li.append(b);
    ul.append(li);
  });
});

const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SR) {
  const mic = document.getElementById("mic");
  mic.hidden = false;
  mic.onclick = () => {
    const rec = new SR();
    rec.lang = "en-IN";
    rec.onresult = e => { input.value = e.results[0][0].transcript; input.focus(); };
    rec.start();
  };
}
